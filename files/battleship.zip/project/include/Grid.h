//David Cigaia

#ifndef GRID_H
#define GRID_H

#include <iostream>
using namespace std;

const char DEFAULT_VALUE=' ';

class Grid
{
    private:
        void grid_initializer(); // metodo che inizializza tutta la griglia =' '
        char att_grid[12][12];
        char def_grid[12][12];
        //int turn_counter;
        bool out_of_bound(int x, int y, int size, bool orientation); // 
        bool is_free(int x, int y);// fa i controllo tramite get_def_cell se la cella è libera 
        


    public:
        bool out(int x,int y); 
        char get_def_cell(int x, int y);
        void set_def_cell(int x, int y, char type);
        char get_att_cell(int x, int y);
        void set_att_cell(int x, int y, char marker);

        // classe per gli errori
        class Invalid{};
        Grid(); // costruttore 

        // metodi di visualizzazione della griglia o reset della griglia
        void cancel_att_grid();// funzione che resetta la griglia di attacco dai colpi andati a segno e a vuoto
        void delete_scans();
        void cancel_presence(int x,int y);// cancella solo la presenza di navi in base alla x e y del sottomarino
        void visualize_grid(); // metodo per stamapre la grilgia 
        string to_string();   //metodo per trasformare la griglia in string

        // metodi per il posizionamento delle ship con i vari controlli
        bool good_position(int x, int y, int ship_size, bool orientation); // metodo che verifica se la casella inserita è buona come centro per la nave
        void set_ship(int x, int y, int ship_size, bool orientation);// metodo che setta la nave partendo dal centro, con le lettere del suo tipo
        void move(int temp_x, int temp_y, int x, int y,int size, bool orientation);// metodo per lo spostamento delle navi

        // metodi inerenti all'azione della cannoniera 
        int get_fire(int x, int y);// metodo che verifica la presenza di una nave avversaria nella casella, ritorna true se presente 
        void set_fire(int x, int y,int val);// metodo che setta la casella =X se la nave è colpita,altrimento =O, quindi modifica la mia griglia di attacco
        int set_hit(int x, int y);// metodo che segnala la nave colpita mettendo la lettera minuscola, ritorna il tipo di nave 

        // metodi inerenti all'azione della nave di supporto
        void set_fixing(int x, int y, int size, bool orientation);// metodo che cambia le lettere minuscole in maiuscole per la riparazione della nave di supporto
        bool find_ship(int x, int y);// metodo che legge la def_grid dell'avversario una cella per volta, ritorna il tipo di nave  

        // metodi inerenti all'azione del sottomarino
        void set_presence(int x, int y, char situation);// metodo che segnala nella tabella la presenza di navi nemiche, indicate con un carattere =Y
        char get_situation(int temp_x, int temp_y);// mi ritorna il caratte della nave trovata per capire se è colpita o no
        bool get_presence(int x, int y);// metodo che ricerca nella tabella avversaria la presena di navi, date x e y del nostro sottomarino,invocato tramite elemento grid dell'avversario
        bool is_scanned(int x, int y);//metodo che ricerca nella tabella se sono presenti Y, per dare una logica al computer su dove sparare

        //metodo per la cancellazione di una nave dalla griglia(utilizzato anche per eliminare la posizione precendete al movimento)
        void delete_ship(int x, int y, int size, bool orientation);// cancella la nave dalla griglia sia in caso di eliminazione completa
                                                                   // che in caso di spostamento, attenzione al momento in cui deve esssere
                                                                   // chiamata in quanto si basa sulle coordinate vecchie e non quelle nuove 

        // metodo che mi trova il centro della nave, poi lo restituisce per la diminuzione della corazza 
        //void find_ship_center(int type,int x, int y, int *x_cener, int *y_center);// mi trova il centro della nave 

};

#endif