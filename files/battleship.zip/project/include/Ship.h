// Milos Trifunovic nm=2042778
#ifndef SHIP_H
#define SHIP_H

#include <string>
#include <vector>

class Ship
{
public:
    class Illegal_Ship{};

	Ship (int x_from, int y_from, int x_to, int y_to, int size);       //l utente digita il punto di inizio e fine della nave e le coordinate arrivano quì convertite in interi
    bool get_orientation();   //true se la nave è orizzontale
    bool is_destroyed();      //restituisce armatura==0
	int get_x();         //restituisco baricentro
	int get_y();         //restituisco baricentro
	int get_size();      //restituisco dimensione (costante, a differenza dell'armatura)
    std::vector<int> get_axis_points();   //salvo le coordinate di tutti i punti della nave
    void move(int new_x, int new_y);    //sposto il baricentro nel nuovo punto. Grid.cpp farà sì che non potrà essere spostata una corazzata
    void decrease_armor();     //la nave viene colpita
    void restore_armor();     //ripristina l'armatura al valore iniziale
    bool is_damaged();        //true se armor<size

private:
    bool out_of_bounds(int x, int y);   //controlla se le coordinate immesse sono fuori dalla griglia
    int armor;
    int size_;
    int x,y;    //coordinate baricentro
    bool horizontal;    //true se orizzontale
};

#endif