//Massimo Campagnaro: n. matricola: 2032517

I file vanno messi nelle proprie cartelle (include per i .h e src per i .cpp), come su moodle perchè il Cmake funzioni
correttamente (purtroppo non è possibile fare un secondo Cmake nella stessa cartella quindi abbiamo optato per tenere il Cmake
che opera con le sottocartelle.

E' fortemente consigliato eseguire il programma con il terminale aperto a schermo intero, se tenuto in finestra è possibile sia
troppo piccola e la griglia non viene visualizzata in modo corretto.

Aggiunte al programma base:
- è stata aggiunta una intelligenza di base ai computer, quando viene trovata una parte di nave con il sottomarino la mossa
successiva sarà di sparare in quel punto con una corazzata;
- è stato aggiunto un argomento in più nel file battaglia_navale, dove oltre agli argomenti pc e cc (per le modalità di gioco)
è possibile mettere un terzo argomento (contando battaglia_navale come argomento) che dà la possibilità di scegliere il nome
del file di log sul quale stampare le mosse (questo anche per poter produrre 2 log diversi come richiesto);
- è stato messo come nome di file di default log.txt per registrare e leggere le mosse nei rispettivi file battaglia_navale.cpp
e replay.cpp;
- è stato impostando un limite di mosse pari a 500, questo perchè con questo numero è possibile avere una buona percentuale di
vittoria in partite tra 2 computer, se sono inferiori gran parte delle partite finisce con il pareggio. Con la logica nella
scelta degli spari applicata per i computer, siamo arrivati a questo numero di mosse (500) per avere più o meno metà delle partite
che non terminano con un pareggio; senza l'intelligenza le mosse minime per ottenere delle vincite era 3000. 

Il programma è stato strutturato in 4 file .cpp e due header.
Il file Grid.cpp contiene la classe Grid dove sono memorizzate le 2 griglie di gioco (la prima di difesa, la seconda di attacco)
e sono presenti vari metodi per modificare le griglie e vedere i caratteri presenti nelle celle. 
Il file Ship.cpp contiene la classe Ship dove sono memorizzate le caratteristiche (comprese le coordinate di posizione) della nave
e sono presenti metodi che ritornano queste caratteristiche o le modificano.
Il file battaglia_navale.cpp contiene il main del gioco, è stato scelto di dare il controllo quasi totale del flusso di dati al main,
quindi nel main sono stati fatti 2 vettori di ship per memorizzare le navi di ogni giocatore (un vettore a testa) e potervi accedere
e 2 oggetti grid (sempre una griglia per giocatore) per fare i posizionamenti e azioni dovuti, inoltre nel main viene gestita la
stampa delle mosse sul file di log.
Il file replay.cpp si occupa della conversione delle mosse presenti nel file di log in griglie di gioco, stampando le griglie
turno per turno in un file di testo, oppure nel terminale (con un delay di 1 secondo tra mossa), attraverso gli argomenti appositi. 

I 2 file di log presenti sono: uno per la partita player/computer log_pc e uno per la partita computer/computer log_cc.