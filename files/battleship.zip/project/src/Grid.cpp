//David Cigaia

#include "Grid.h"
#include <iostream>

//Costruttore
Grid::Grid()
{
    grid_initializer();
}
void Grid::grid_initializer()
{
    for(int i=0;i<12;i++) // righe
    {
        for(int j=0;j<12;j++) // colonne
        {
            att_grid[i][j]=DEFAULT_VALUE;
            def_grid[i][j]=DEFAULT_VALUE;
        }
    }
}


//Metodi private
bool Grid::out_of_bound(int x, int y, int size, bool orientation) // mi dice se la posizione del centro va furoi dalla griglia
{                                                                 // questo quando voglio spostare la nave 
    if(orientation)
    {
        if(x < size/2 || x > 11-(size/2))
        return true;
        else
        return false;
    }else
    {
        if(y < size/2 || y > 11-(size-1)/2)
        return true;
        else
        return false;
    }
}

bool Grid::is_free(int x, int y)// verifica se le celle sono libere o meno
{
    return get_def_cell(x,y)==' ';
}

bool Grid::out(int x, int y) // verifica se il colpo della cannoniera è interno o esterno alla griglia
{
    if(x<0 || x>11 || y<0 || y>11)
    {
        return true;
    }else
    {
        return false;
    }
}


//Metodi public
char Grid::get_def_cell(int x, int y)// mi ritorna il carattere contenuto nella cella x,y della tabella def
{
    return def_grid[x][y];
}

void Grid::set_def_cell(int x, int y, char type) // mi setta cella per cella della griglia
{
    def_grid[x][y]=type;
}

char Grid::get_att_cell(int x, int y)
{
    return att_grid[x][y];
}

void Grid::set_att_cell(int x, int y, char marker) // metodo che si occupa di settare le celle nella griglia di attacco 
{
    att_grid[x][y]=marker;
}


//metodi di visualizzazione della griglia o reset della griglia

//Funzioni di visualize_grid e print_grid
string horizontal_lines()
{
    string s = "  ";
    for(int i = 0; i < 12; i++)
    {   s += " ---";}
    return s;
}
string space(int spaces_number)
{
    string s;
    for(int i=0; i<spaces_number; i++)
    {   s += " ";}
    return s;
}
string vertical_lines(char grid[12][12], int i)
{
    string s;
    if(i < 9)
    {   s = (char) (i + 65);} //sfrutto la codifica ASCII
    else
    {   s = (char) (i + 67);} //per saltare le lettere J e K
    for(int j = 0; j < 12; j++)
    {   s += " | " + string(1, grid[i][j]);}
    s += " |";
    return s;
}
string numbers(int n)
{
    string s = " ";
    for(int i = 1; i < n+1; i++)
    {
        if(i < 11)
        {   s += "   " + to_string(i);}
        else
        {   s += "  " + to_string(i);}
    }
    return s;
}
string Grid::to_string()
{
    string s = "\n";
    for(int i = 0; i < 12; i++)
    {
        s += horizontal_lines();
        s += space(13);
        s += horizontal_lines();
        s += "\n";
        s += vertical_lines(def_grid, i);
        s += space(12);
        s += vertical_lines(att_grid, i);
        s += "\n";
    }
    s += horizontal_lines();
    s += space(13);
    s += horizontal_lines();
    s += "\n";
    s += numbers(12);
    s += space(13);
    s += numbers(12);
    s += "\n";
    return s;
}
void Grid::visualize_grid() 
{
    cout<<to_string();
}

void Grid::cancel_att_grid()// reimportsa tutte le celle della griglia di attacco =' ' in qunto questa potrebbe non essere aggiornata 
{
    for(int i=0;i<12;i++) // scorro le colonne 
    {
        for(int j=0;j<12;j++)// scorro le righe
        {
            set_att_cell(i,j,' ');
        }
    }
}

/*void Grid::cancel_presence(int x,int y)// cancella solo la presenza di navi in base alla x e y del sottomarino
{
    for(int i=x-2; i<5;i++)
    {
        for(int j=y-2; j<5;j++)
        {
            set_att_cell(i,j,' ');
        }
    }
}*/

void Grid::delete_scans()
{
    for(int i=0; i<12; i++)
    {
        for(int j=0; j<12; j++)  
        {
            if(get_att_cell(i, j) == 'Y')
            {
                set_att_cell(i, j, ' ');
            }
        }
    }
}

//metodi di posizionamente delle ship con i controlli
bool Grid::good_position(int x, int y,int size,bool orientation)// serve solo per il move delle navi da supporto e per le navi da esplorazione
{
    if(out_of_bound(x,y,size,orientation))
    return false;

    if(size==1)// caso del sottomarino
    {
        if(is_free(x,y))// non ci interessa l'orientazione ma solo se la casella è libera o meno 
        {
            return true;
        }else
        {
            return false;
        }
        
    }else if(size==3)// caso nave da supporto
    {
        if(orientation)// nave da supporto orizzontale
        {
            if(get_def_cell(x,y)==' ' && get_def_cell(x-1,y)==' ' && get_def_cell(x+1,y)==' ' )
            {
                return true; // la nave ha tutte le caselle libere per starci
            }else
            {
                return false;// la nave ha delle caselle occupate
            }

            /*for(i=0; i<size; i++)//MODIFICA: questo for equivale al controllo con gli &
            {
                if(is_free(x-1+i, y))
                {   return true;}
                else
                {   return false;}
            }*/
        }else// nave da supporto verticale
        {
            if(get_def_cell(x,y)==' ' && get_def_cell(x,y-1)==' ' && get_def_cell(x,y+1)==' ' )
            {
                return true;// la nave ha tutte le caselle liber eper starci
            }else
                {
                return false;// la nave ha delle caselle occupate
            }

            /*for(i=0; i<size; i++)//MODIFICA: questo for equivale al controllo con gli &
            {
                if(is_free(x, y-1+i))
                {   return true;}
                else
                {   return false;}
            }*/
        }
    }else if(size==5)// caso cannoniera
    {
        if(orientation)// cannoniera orizzontale
        {
            if(get_def_cell(x,y)==' ' && get_def_cell(x-1,y)==' ' && get_def_cell(x+1,y)==' ' && get_def_cell(x-2,y)==' ' && get_def_cell(x+2,y)==' ')
            {
                return true; // la nave ha tutte le caselle libere per starci
            }else
            {
                return false;// la nave ha delle caselle occupate
            }

            /*for(i=0; i<size; i++)//MODIFICA: questo for equivale al controllo con gli &
            {
                if(is_free(x-2+i, y))
                {   return true;}
                else
                {   return false;}
            }*/

        }else// cannoniera verticale
        {
            if(get_def_cell(x,y)==' ' && get_def_cell(x,y-1)==' ' && get_def_cell(x,y+1)==' ' && get_def_cell(x,y-2)==' ' && get_def_cell(x,y+2)==' ')
            {
                return true;// la nave ha tutte le caselle libere per starci
            }else
            {
                return false;// la nave ha delle caselle occupate
            }

            /*for(i=0; i<size; i++)//MODIFICA: questo for equivale al controllo con gli &
            {
                if(is_free(x, y-2+i))
                {   return true;}
                else
                {   return false;}
            }*/

        }
        
    }
    return false;   //se e' arrivato fino a qui, significa che la size non e' della size corretta
}

void Grid::set_ship(int x, int y, int size, bool orientation)// nel main sarà da modificare le coordinate della corrispodente ship
{
    if(good_position(x,y,size,orientation))
    {
        char type;
        
        if(size==1)
        {
            type='E';
            set_def_cell(x,y,type);
        }else if(size==5)
        {
            type='C';
            if(orientation)// caso in cui sia orizzontale
            {
                for(int i=0;i<5;i++)
                {
                    set_def_cell(x-2+i,y,type);// ciclo che stampaa le lettere orizzontalmente 
                }
            }else// caso in cui sia verticale
            {
                for(int i=0;i<5;i++)
                {
                    set_def_cell(x,y-2+i,type); // cilco che stampa le lettere verticalmente 
                }
            }
        }else if(size==3)
        {
            type='S';
            if(orientation)
            {
                for(int i=0;i<3;i++)
                {
                    set_def_cell(x-1+i,y,type);// ciclo che stampaa le lettere orizzontalmente 
                }
            }else
            {
                for(int i=0;i<3;i++)
                {
                    set_def_cell(x,y-1+i,type);// ciclo che stampaa le lettere orizzontalmente 
                }
            }
        }else
        {
            throw Invalid();
        }

    }else
    {
        throw Invalid();
    }
}

void Grid::move(int temp_x, int temp_y, int x, int y, int size, bool orientation)// x,y sono le nuove coordinate del centro, mentre temp_x,temp_y sono le coordinate del centro di partenza 
{
    // non posso chiamare in questo punto delete_ship altrimeti avrebbe come coordinate del centro quelle nuove della nave 
    // e non cancellerebbe quella vecchia già presente in griglia 
    //prima di move dovra essere chiamato good_position all'interno del main

    //good_position(x,y,size,orientation);
    // non chiamiamo qua dentro i good position in quanto poi sarebbe complicata la gestione degli errori 
    
    /*if(good_position(x,y,size,orientation))
    {
        if(size==5)
        throw Invalid();

        if(size==1)// caso del sottomarino
        {
            set_def_cell(x,y,get_def_cell(temp_x,temp_y));// copio la cella nella nuova posizione
            set_def_cell(temp_x,temp_y,' ');//resetto la cella a vuota 
        }

        if(orientation)// caso orizzontale 
        {
            for(int i=0;i<3;i++)// mi serve per scorrere le celle
            {
                set_def_cell(x-1+i,y,get_def_cell(temp_x-1+i,temp_y));//copio le celle in ordine nelle nuove posizioni
                set_def_cell(temp_x-1+i,temp_y,' ');// resetto le celle di partenza a celle vuote
            }
        }else// caso verticale 
        {
            for(int i=0;i<3;i++)// mi serve per scorrere le celle
            {
                set_def_cell(x,y-1+i,get_def_cell(temp_x,temp_y-1+i));// copio le celle in ordine nelle nuove celle 
                set_def_cell(temp_x,temp_y-1+i,' ');// resetto le celle di partenza a celle vuote 
            }
        }
    }else
    {
        throw Invalid();
    }*/

    //MODIFICA: mancava un if size == 3, poi non dovrebbe servire size==5 perche' escludiamo tutte le size che non sono 1 o 3 con l'else finale

    if(!good_position(x,y,size,orientation))
    {   throw Invalid();}

    if(size==1)// caso del sottomarino
    {
        set_def_cell(x,y,get_def_cell(temp_x,temp_y));// copio la cella nella nuova posizione
        set_def_cell(temp_x,temp_y,' ');//resetto la cella a vuota 
    }
    else if(size == 3)// caso della nave di supporto 
    {
        if(orientation)// caso orrizzontale
        {
            for(int i=0;i<3;i++)// mi serve per scorrere le celle
            {
                set_def_cell(x-1+i,y,get_def_cell(temp_x-1+i,temp_y));//copio le celle in ordine nelle nuove posizioni
                set_def_cell(temp_x-1+i,temp_y,' ');// resetto le celle di partenza a celle vuote
            }
        }else// caso verticale 
        {
            for(int i=0;i<3;i++)// mi serve per scorrere le celle
            {
                set_def_cell(x,y-1+i,get_def_cell(temp_x,temp_y-1+i));// copio le celle in ordine nelle nuove celle 
                set_def_cell(temp_x,temp_y-1+i,' ');// resetto le celle di partenza a celle vuote 
            }
        }
    }
    else    //qualunque altra size non e' accettata
    {   throw Invalid();}
}


//metodi inerenti all'azione della cannoniera
int Grid::get_fire(int x, int y)// metodo che deve guardare nella griglia di difesa dell'avversario per vedre se nella posizione x,y è
{                              // presente una nave, dovra essere invocato nel main con l'oggetto grid corrispondente all'avversario
    if(!out(x,y))
    {
        if(get_def_cell(x,y)!=' ' && get_def_cell(x,y)!='c' && get_def_cell(x,y)!='s' && get_def_cell(x,y)!='e')// verifico che sia presente la nave e che non sia già colpita
        {                                                                                                       
            return 1;                                                                                            
        }else if(get_def_cell(x,y)=='c' || get_def_cell(x,y)=='s')//|| get_def_cell(x,y)=='e'//caso in cui colpisco una parte già colpita
        {
            return 2;
        }else if(get_def_cell(x,y)==' ')
        {
            return 3;
        }
    }
    throw Invalid();
}

/*P.Grid::set_fire(x,y,C.Grid::get_fire(x,y));
if(C.Grid::get_def_cell(x,y)=='E')
{
    //fai in modo che corazza--
    //sottomarino camncellato
}
C.Grid::set_hit(x,y);*/

void Grid::set_fire(int x,int y,int val)// metodo che modifica la mia griglia di attacco in base se è stata colpita un nave o meno
{                               //
    if(val==1)
    {
        set_att_cell(x,y,'X'); // setto la cella sulla mia griglia di attacco a colpita =X
    }else if(val==2)
    {
        set_att_cell(x,y,'x'); // setto la casella sulla mia griglia di attacco a cella già colpita
    }else if(val==3)
    {
        set_att_cell(x,y,'O'); // setto la cella sulla mia griglia di attacco a mancata =O
    }
} 

int  Grid::set_hit(int x, int y)// metodo che va a settare sulla griglia di difesa in posizione della nave che è stata colpita
{                               // cambiando la sua lettera maiuscola con una minuscola, poi nel main andrà diminuita anche la sua corazza
                                // invocato con l'oggetto grid del giocatore che sta subendo l'attacco

    if(!is_free(x,y))// guarda se le cella è occcupata o meno 
    {
        if(get_def_cell(x,y)=='C') // leggo il carattere nella cella 
        {
            set_def_cell(x,y,'c'); // ricordarsi nel main di diminuire la corazza della nave 
            return 1;// ritorna il tipo di nave colpita
        }else if(get_def_cell(x,y)=='S')// leggo il carattere nella cella 
        {
            set_def_cell(x,y,'s'); // ricordarsi nel main di diminuire la corazza della nave 
            return 2;// ritorna il tipo di nave colpita
        }else if(get_def_cell(x,y)=='E')// leggo il carattere nella cella 
        {
            set_def_cell(x,y,' ');
            return 3;// ritorna il tipo di nave colpita 
        }
    }
    throw Invalid();
}


//metodi inerenti all'azione della nave di supporto
void Grid::set_fixing(int x, int y, int size, bool orientation)// metodo che date le coordinate del centro della nave, la sua size e orientation, ripristina le lettere minuscole in maiuscole
{                                                              // ricordarsi nel main prima o dopo l'invocazione di questo metodo di ripristinare anche la corazzza della nave 
                                                               // invocato dopo il find_ship                                  
    if (orientation) // caso nave orizzontale
    {
        if(size==5) // caso cannoniera
        {
            for(int i=0;i<size;i++)// cilco for per scorrere tutte le celle
            {
                set_def_cell(x-2+i,y,'C');
            }
        }else if(size==3) // caso nave di supporto
        {
            for(int i=0;i<size;i++)// cilco for per scorrere tutte le celle
            {
                set_def_cell(x-1+i,y,'S');
            }
        }else
        {
            throw Invalid();
        }
    }else // caso nave verticale
    {
        if(size==5) // caso cannoniera
        {
            for(int i=0;i<size;i++)// cilco for per scorrere tutte le celle
            {
                set_def_cell(x,y-2+i,'C');
            }
        }else if(size==3) // caso nave di supporto
        {
            for(int i=0;i<size;i++)// cilco for per scorrere tutte le celle
            {
                set_def_cell(x,y-1+i,'S');
            }
        }else
        {
            throw Invalid();
        }
    }
}

bool Grid::find_ship(int x, int y)// metodo che date le coordinate di una delle celle appartenenti al quadrato 3x3 della nave di 
{                                 // supporto ritorna se c'è una nave o meno, non ritorna la tipologia in quanto poi sarebbe da metterci
                                  // un else per gestire il caso in cui non ci sia nulla 
    if(get_def_cell(x,y)=='C' || get_def_cell(x,y)=='c' || get_def_cell(x,y)=='S' || get_def_cell(x,y)=='s')
    {
        return true;// caso in cui ci sia una nave 
    }else
    {
        return false;// caso in cui non ci sia una nave 
    }
    // da notare che se c'è un sottomarino nel raggio non dice niente in quanto questo può essere solamanete vivo o affondato                
}

/*for(int i=y-1; i<3; i++) // scorro le colonne
{
    for(int j=x-1; j<3; j++) // scorro le righe 
    {
        if(P.Grid::find_ship(i,j))// Se c'è una nave ...
        }
        //invochi il metodo che ti trova la nave dalla cella che ha coordinate x=i, y=j
        //trovi il centro della nave 
        //imposti la corazza al massimo 
        P.Grid.:set_fixing(x,y,size,orientation);// invocato con le info della nave trovata 
        {
    } 
}*/


//metodi inerenti all'azione del sottomarino
void Grid::set_presence(int x, int y, char situation )// metodo che setta la presenza di navi nemiche, dopo il movimento del sottomarino 
{                                                     //  invocato nell'if la cui condizione è get_presence, invocato da un oggetto grid dell'avversario
                                                      // la situation è data dall'invocazione del metodo get_situation chimato dalla grid avversria
    if(situation=='X')
    set_att_cell(x,y,situation);// setta la cella a colpita
    else if (situation=='Y')
    set_att_cell(x,y,situation);// setta la cella a non colpita
    else
    set_att_cell(x,y,situation);// setta la cella a vuoto
}

char Grid::get_situation(int temp_x, int temp_y)// ricava dalla griglia dell'avversario lo stato della parte della nava individuata dal radar
{
    if(get_def_cell(temp_x,temp_y)=='c' || get_def_cell(temp_x,temp_y)=='s') // caso in cui trovi una corazzata colpita o una supporto colpita
    return 'X';
    else if(get_def_cell(temp_x,temp_y)=='C' || get_def_cell(temp_x,temp_y)=='S' || get_def_cell(temp_x,temp_y)=='E')
    return 'Y'; // caso in cui trovi una parte di nave qualsiasi ancora non colpita
    else
    return ' ';// caso in cui non ci sia nulla 
}

bool Grid::get_presence(int temp_x, int temp_y)// metodo che ricerca nella griglia dell'avvarsario se nel raggio del nostro sottomarino, date le cooordinate x e y
{                                              // ci sono navi, sarà invocato nel main all'interno di un for che scorre il quadrato 5x5
    return !is_free(temp_x,temp_y);            // e che abilita un if per la modifica  
}

bool Grid::is_scanned(int x, int y)
{
    return get_att_cell(x,y) == 'Y';
}

//metodo per la cancellazione di una nave dalla griglia
void Grid::delete_ship(int x, int y, int size, bool orientation)// metodo che verrà utilizzato quando è da cancellare una nave dalla griglia
{                                                               // perchè la corazza è arrivata a 0, e poi chiamare il distruttore per quella nave 
                                                                
    if(size==1)
    {   set_def_cell(x,y,' ');} // caso in cui il sottomarino venga eliminato
    else if (orientation) // caso nave orizzontale
    {
        if(size==5) // caso in cui la cannoniera venga eliminata
        {
            for(int i=0;i<size;i++)// cilco for per scorrere tutte le celle
            {
                set_def_cell(x-2+i,y,' ');// Riporto tutte le caselle =' '
            }
        }else if(size==3) // caso nave di supporto eliminata
        {
            for(int i=0;i<size;i++)// cilco for per scorrere tutte le celle
            {
                set_def_cell(x-1+i,y,' ');// Riporto tutte le caselle =' '
            }
        }else
        {
            throw Invalid();
        }
    }else // caso nave verticale
    {
        if(size==5) // caso in cui la cannoniera venga eliminata
        {
            for(int i=0;i<size;i++)// cilco for per scorrere tutte le celle
            {
                set_def_cell(x,y-2+i,' ');// Riporto tutte le caselle =' '
            }
        }else if(size==3) // caso nave di supporto eliminata
        {
            for(int i=0;i<size;i++)// cilco for per scorrere tutte le celle
            {
                set_def_cell(x,y-1+i,' ');// Riporto tutte le caselle =' '
            }
        }else
        {
            throw Invalid();
        }
    }
}

//metodo che mi trova il centro della nave, poi lo restituisce per la diminuzione/aumento della corazza
/*void Grid::find_ship_center(int type,int x, int y, int *x_center, int *y_center) //funzione che da il tipo restituito da una funzione mi dice il centro della nave
{                                                                                //utile per ricerca e diminuzione della corazza, il type corrisponde al risultato di get_fire 
                                                                                 //ad *x_center e *y_center corrisponderanno dei valori int passati per indirizzo
                                                                                 //x e y sono le coordinate del punto in cui ho trovato la nave 
    int a,b;// dove a corrisponde alla x e b alla y
    int size;
    if(type==1)// nave corazzata
    {
        size=5;
        if(get_def_cell(x+1,y)!=' ' || get_def_cell(x-1,y)!=' ')//nave orizzontale
        {



            *x_center=a;
            *y_center=b;
        }else//nave verticale
        {



            *x_center=a;
            *y_center=b;
        }

    }else if(type==2)//nave di supporto
    {
        size=3;
        if(get_def_cell(x+1,y)!=' ' || get_def_cell(x-1,y)!=' ')//nave orizzontale
        {



            *x_center=a;
            *y_center=b;
        }else//nave verticale
        {



            *x_center=a;
            *y_center=b;
        }
    }else if(type==3)//sottomarino
    {
        *x_center=x; 
        *y_center=y;
    }
}*/
