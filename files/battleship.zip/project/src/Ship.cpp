// Milos Trifunovic nm=2042778
#include "Ship.h"
#include <vector>

Ship::Ship (int x_from, int y_from, int x_to, int y_to, int size)    //l utente digita 2 punti (es. B6 B10 per corazzata e arrivano qui già "convertite in interi") (le coordinate di inizio e fine)
    {
        if(!(size == 5 || size == 3 || size == 1))     //le dimensioni possibili sono 3
        {   throw Illegal_Ship();}
        size_ = size;
        armor = size;
        if(out_of_bounds(x_from, y_from) || out_of_bounds(x_to, y_to))
        {   throw Illegal_Ship();}
        if(y_from == y_to)              //se l altezza è costante, è orizzontale
        {   horizontal = true;
            if(abs(x_to-x_from)!=size_-1)   //uso valore assoluto in quanto può esserev x_from>x_to
            {   throw Illegal_Ship();}
        }
        else if(x_from == x_to)         
        {   horizontal = false;
            if(abs(y_to-y_from)!=size_-1)
            {   throw Illegal_Ship();}
        }
        else
        {   throw Illegal_Ship();}
    
        x = (x_from+x_to)/2;        //calcolo il baricentro usando le coordinate di inizio e fine nave
        y = (y_from+y_to)/2;
    }

    bool Ship::out_of_bounds(int x, int y)
    {
        if(x < 0 || x >= 12)        //uso l'intervallo [0,11] e non [1,12] 
        {   return true;}
        if(y < 0 || y >= 12)
        {   return true;}
        return false;
    }

    bool Ship::get_orientation()
    {
        return horizontal;
    }

	int Ship::get_x()
    {
        return x;
    }

	int Ship::get_y()
    {
        return y;
    }

    int Ship::get_size()
    {
        return size_;
    }
    
    void Ship::decrease_armor()   //invocato ogni volta che la nave viene colpita
    {
        armor--;
    }

    void Ship::restore_armor()    //invocato ogni volta che la nave viene curata
    {
        armor = size_;
    }
    
	bool Ship::is_destroyed()
    {
        return armor == 0;
    }

    bool Ship::is_damaged()
    {
        return armor < size_;
    }

    std::vector<int> Ship::get_axis_points()     
    {
        std::vector<int> axis_points;
        for(int i=0; i<size_; i++)
        {
            if(horizontal)
            {   axis_points.push_back(x-(size_/2)+i);}      //se la nave è orizzontale scorro orizzontalmente, altrimenti salvo le ordinate(essendo l'ascissa uguale)
            else
            {   axis_points.push_back(y-(size_/2)+i);}
        }
        return axis_points;
    }

    void Ship::move(int new_x, int new_y)  //Azioni del sottomarino e della nave di supporto. Sposto il baricentro nel nuovo punto (se valido). 
    {
        if(out_of_bounds(new_x, new_y))    
        {   throw Illegal_Ship();}
        x = new_x;
        y = new_y;
    }