//Massimo Campagnaro, n. matricola: 2032517

#include <iostream>
#include <fstream>
#include <ctype.h>
#include <string.h>
#include <vector>
#include "Grid.h"
#include "Ship.h"

using namespace std;

int int_converter(char x_char);    //converte una lettera in un intero: A=0, B=1... escluse J e K
char char_converter(int x_int);  //converte le coordinate intere in caratteri, da stampare sul file di log
string ship_name(int size);     //ritorna il nome della nave sotto forma di stringa
int corresponding_type(int size, vector<Ship> &ships);   //trova la ship con la size immessa e ne ritorna l'indice del vettore
int corresponding_ship(int x, int y, vector<Ship> &ships); //trova la ship con le coordinate di centro corrispondenti a quelle immesse e lo ritorna
int piece_of_ship(int x, int y, vector<Ship> &ships);    //trova la ship che sta occupando le coordinate immesse e ne restituisce l'indice
void remove_ship(int index, vector<Ship> &ships);       //rimuove la ship con l'indice immesso dal vettore di ship


int main(int argc, char **argv)
{
    srand (time(NULL));     //imposto il seed iniziale a time(NULL)

    //pc = true, cc = false
    bool game_mode = true;  //di default metto true, partita con il player
    string log_file = "log.txt";    //metto log.txt come file di scrittura di default
    int move_limit = 500;   //impostato il limite di mosse a 500 per i motivi spiegati nel README
     
    if(argc == 2 || argc == 3)
    {
        if(strcmp(argv[1], "pc") == 0)  //con argomento pc avro' un partita player vs computer
        {   game_mode = true;}
        if(strcmp(argv[1], "cc") == 0)  //con argomento cc avro' un partita computer vs computer
        {   game_mode = false;}
        if(argc == 3)               //se sono presenti 3 argomenti
        {   log_file = argv[2];}    //il terzo sara' il nome del file di scrittura del log
    }

    fstream write;
    write.open(log_file,ios::out);  //sovrascrivo il testo ogni volta che chiudo e riapro il file   

    //posizionamento delle ship del computer 1
    Grid C;     //griglia del computer 1
    vector<Ship> C_ships;   //vettore del computer 1

    bool stop;
    int size = 5;
    for(int i = 0; i < 8; i++)  //uso il for per scorrere il vettore di ship e inserirle
    {
        int x1, y1, x2, y2; //servono anche per il log
        bool stop = false;
        while(!stop)    //while fatto in modo tale che venga interrotto il ciclo se non ci sono errori
        {
            try
            {
                x1 = rand()%12;     //prima x casuale
                y1 = rand()%12;     //prima y casuale
                //per avere un criterio nella scelta, in questo modo ci sono meno prove che mettendo tutti i numeri casuali
                if(rand()%2 == 0)    //scelgo casualmente cosa fare...
                {   //...se tenere come termine uguale la x
                    x2 = x1;   
                    if(rand()%2 == 0)    //di conseguenza l'altro termine sara' scelto, sempre casualmente, tra
                    {   y2 = y1 + size-1;}  //uno piu' grande di size-1
                    else
                    {   y2 = y1 - (size-1);}  //e uno piu' piccolo di size-1
                }
                else
                {   //...se tenere come termine uguale la y
                    y2 = y1;
                    if(rand()%2 == 0)
                    {   x2 = x1 + size-1;}
                    else
                    {   x2 = x1 - (size-1);}
                }   //testando con questo metodo mi bastano in media 10 cicli del while con i catch,
                    //mettendo tutti i numeri casuali ho invece una media di 1000

                C_ships.push_back(Ship(x1, y1, x2, y2, size));    //creo una ship del vettore con le coordinate date
                C.set_ship(C_ships[i].get_x(), C_ships[i].get_y(), size, C_ships[i].get_orientation());  //setto la ship prendendomi le coordinate con i get

                stop = true;
                //scrivo sul file di log, arrivati a questo punto le coordinate sono prive di errori e gia' inserite in griglia e vettore di ship
                if(write.is_open())
                {   write<<char_converter(x1)<<y1+1<<" "<<char_converter(x2)<<y2+1<<endl;}
            }
            catch(const Ship::Illegal_Ship& e)
            {}
            catch(const Grid::Invalid& e)
            {
                C_ships.pop_back();     //il controllo sulla griglia viene fatto in seguito alla creazione della ship quindi la ship 
                //e' gia' presente nel vector di ship quando viene dato l'errore Grid::invalid, devo togliere la ship dal vector e farla reinserire
            }
        }
        if(i == 2 || i == 5)    //se ha messo 3 ship di size 5 passo a quelle di size 3 e cosi via (si ferma a 8 quindi solo 2 sottomarini)
        size -= 2;
    }

    //posizionamento navi del player, o computer 2
    Grid P;     //griglia del player
    vector<Ship> P_ships;   //vettore del player

    size = 5;   //risetto la size a 5
    for(int i = 0; i < 8; i++)
    {
        string position1, position2;
        int x1, y1, x2, y2; //servono anche per il log
        stop = false;
        while(!stop)    //while fatto in modo tale che venga interrotto il ciclo se non ci sono errori
        {
            try
            {
                if(game_mode)   //se partita PC
                {
                    cout<<"inserisci le coordinate per "<<ship_name(size)<<" : ";
                    cin>>position1>>position2;
                    if(position1 == "XX" && position2 == "XX")
                    {   
                        P.visualize_grid();
                    }
                    y1 = stoi(position1.substr(1));
                    y1--;   //sottraggo di uno per ottenere numeri da 0 a 11 (per valori array)
                    y2 = stoi(position2.substr(1)); 
                    y2--;   //sottraggo di uno per ottenere numeri da 0 a 11 (per valori array)
                    x1 = int_converter(position1[0]);  //converto il primo valore da carattere a intero
                    x2 = int_converter(position2[0]);
                }
                else    //se partita CC
                {
                    x1 = rand()%12;     //prima x casuale
                    y1 = rand()%12;     //prima y casuale
                    //per avere un criterio nella scelta, in questo modo ci sono meno prove che mettendo tutti i numeri casuali
                    if(rand()%2 == 0)    //scelgo casualmente cosa fare...
                    {   //...se tenere come termine uguale la x
                        x2 = x1;   
                        if(rand()%2 == 0)    //di conseguenza l'altro termine sara' scelto, sempre casualmente, tra
                        {   y2 = y1 + size-1;}  //uno piu' grande di size-1
                        else
                        {   y2 = y1 - (size-1);}  //e uno piu' piccolo di size-1
                    }
                    else
                    {   //...se tenere come termine uguale la y
                        y2 = y1;
                        if(rand()%2 == 0)
                        {   x2 = x1 + size-1;}
                        else
                        {   x2 = x1 - (size-1);}
                    }   //testando con questo metodo mi bastano in media 10 cicli del while con i catch,
                }       //mettendo tutti i numeri casuali ho invece una media di 1000
                
                P_ships.push_back(Ship(x1, y1, x2, y2, size));    //aggiungo al vettore una ship con le coordinate date
                P.set_ship(P_ships[i].get_x(), P_ships[i].get_y(), size, P_ships[i].get_orientation());  //setto la ship prendendomi le caratteristiche con i get
                
                stop = true;
                //scrivo sul file di log
                if(write.is_open())
                {
                    if(game_mode)
                    {   write<<position1<<" "<<position2<<endl;}
                    else
                    {   write<<char_converter(x1)<<y1+1<<" "<<char_converter(x2)<<y2+1<<endl;}
                }
            }
            catch(const Ship::Illegal_Ship& e)
            {
                if(game_mode)
                {   cout<<"dimensione o coordinate della nave invalide, riprova... ";}
            
            }
            catch(const Grid::Invalid& e)
            {
                P_ships.pop_back();     //il controllo sulla griglia viene fatto in seguito alla creazione della ship quindi la ship 
                //e' gia' presente nel vector di ship quando viene dato l'errore Grid::invalid, devo togliere la ship dal vector e farla reinserire
                if(game_mode)   //se partita PC do' un messaggio
                { cout<<"non puoi mettere una nave sopra un altra, riprova... ";}
            }
            catch(const invalid_argument& e)
            {
                if(game_mode)   //se partita PC do' un messaggio
                {   cout<<"e' stato inserito un comando speciale o un formato non valido"<<endl;}
            }
        }
        if(i == 2 || i == 5)    //se ha messo 3 ship di size 5 passo a quelle di size 3 (si ferma a 8 quindi solo 2 sottomarini)
        size -= 2;
    }

    //scelgo chi inizia
    bool first_player = (rand()%2==0);  //1 player, 0 computer

    //salvo su log il giocatore che ha iniziato
    if(write.is_open())
    {   write<<first_player<<endl;}

    //azioni
    int turn_counter = 0;   //contatore dei turni  
    bool win = false;    //il player vince quando win==1, il computer con win==0 
    while(turn_counter<move_limit && !win)
    {
        string position1, position2;
        int x_ship, y_ship, x_action, y_action;
        int P_ship_index, C_ship_index;
        stop = false;
        if(turn_counter%2 != first_player)  //se first_player e' = 1 iniziera' il player, se e' = 0 iniziera' il computer
        {   //turno del Player
        while(!stop)    //while fatto in modo tale che venga interrotto il ciclo se non ci sono errori
        {
            try
            {
            if(game_mode)
            {
                cout<<"inserisci l'azione: ";
                cin>>position1>>position2;
                if(position1 == "XX" && position2 == "XX")
                {   
                    P.visualize_grid();
                }
                if(position1 == "AA" && position2 == "AA")
                {
                    P.delete_scans();
                }
                y_ship = stoi(position1.substr(1));
                y_ship--;   //sottraggo di uno per ottenere numeri da 0 a 11 (per valori array)
                y_action = stoi(position2.substr(1)); 
                y_action--;   //sottraggo di uno per ottenere numeri da 0 a 11 (per valori array)
                x_ship = int_converter(position1[0]);
                x_action = int_converter(position2[0]);
                P_ship_index = corresponding_ship(x_ship, y_ship, P_ships); //trovo la nave con il centro corrispondente alle ccordinate
                if(C_ship_index == -1)      //se non la trovo
                {   throw Ship::Illegal_Ship();} //lancio un errore Ship
            }
            else
            {
                bool smart_move = false;
                P_ship_index = corresponding_type(5, P_ships);  //salvo l'indice di una cannoniera, se smart move diventa true, sara' la ship che fa l'azione
                if(P_ship_index != -1)  //se non viene trovata una cannoniera, non svolgo neanche la ricerca delle Y
                {
                    for(int i=0; i<12 && !smart_move; i++)  //fermo il ciclo se viene trovata una smart move
                    {
                        for(int j=0; j<12 && !smart_move; j++)  //fermo il ciclo se viene trovata una smart move
                        {
                            if(P.is_scanned(i, j))  //se viene trovata una Y sulla griglia di attacco
                            {   //salvo le coordinate di questo punto come coordinate dell'azione e imposto smart_move a true
                                x_action = i;
                                y_action = j;
                                smart_move = true;
                                //memorizzo anche le coordinate della ship
                                x_ship = P_ships[P_ship_index].get_x();
                                y_ship = P_ships[P_ship_index].get_y();
                            }
                        }
                    }
                }
                if(!smart_move || P_ship_index==-1) //se non e' stata trovata una smart move, oppure non sono presenti cannoniere...
                {
                    P_ship_index = rand()%(P_ships.size()); //...scelgo casualmente una ship dall'array di ship
                    //memorizzole coordinate della ship
                    x_ship = P_ships[P_ship_index].get_x();
                    y_ship = P_ships[P_ship_index].get_y();
                    //memorizzo coordinate per l'azione, scelte in modo casuale
                    x_action = rand()%12;
                    y_action = rand()%12;
                }
            }
            //memorizzo in variabili la size e l'orientation della nave
            int ship_size = P_ships[P_ship_index].get_size();
            bool ship_orientation = P_ships[P_ship_index].get_orientation();
            //differenzio l'azione da svolgere in base alla size, che mi dice il tipo di ship indirettamente
            if(ship_size == 5)  //caso della corazzata
            {
                if(C.get_fire(x_action, y_action) == 1) //caso in cui viene colpita una parte intatta di nave
                {
                    C_ship_index = piece_of_ship(x_action, y_action, C_ships); //trovo la nave corrispondente del computer, nave attaccata
                    if(C_ship_index == -1)              //posso togliere questo controllo in quanto se la nave e' stata trovata sulla griglia allora
                    {   throw Ship::Illegal_Ship();}     //e' presente anche nel vettore, puo' essere tenuto come un controllo ulteriore
                    //aggiorno griglia e armatura
                    P.set_fire(x_action, y_action, 1);      //segnalo nella griglia del player la nave colpita sulla griglia d'attacco con una X
                    C_ships[C_ship_index].decrease_armor(); //diminuisco l'armatura della nave corrispondente
                    C.set_hit(x_action, y_action);          //e aggiorno anche sulla griglia del computer segnalando la parte di nave colpita
                    if(C_ships[C_ship_index].is_destroyed())//se distrutta
                    {   //elimino la ship dalla griglia con delete_ship
                        C.delete_ship(C_ships[C_ship_index].get_x(), C_ships[C_ship_index].get_y(),
                            C_ships[C_ship_index].get_size(), C_ships[C_ship_index].get_orientation());
                        //elimino la ship dal vettore ships
                        remove_ship(C_ship_index, C_ships);
                        if(C_ships.size() == 0)
                        {   
                            win = true; //se il vettore non contiene navi, sono state tutte distrutte, la partita viene vinta dal player
                            if(game_mode)
                            {   cout<<"il Player ha vinto, tutte le navi nemiche sono state distrutte!"<<endl;}
                            else
                            {   cout<<"ha vinto il Computer che ha giocato al posto del Player"<<endl;}
                        }    
                    }
                }
                else if(C.get_fire(x_action, y_action) == 2) //caso in cui viene colpita una parte gia' danneggiata di nave
                {   //non sara' necessario aggiornare l'armatura o la griglia del computer, in quanto la nave era gia' colpita in quel punto
                    P.set_fire(x_action, y_action, 2);   //segnalo nella griglia del player la nave colpita con una x minuscola
                }
                else    //get_fire sara' uguale a 3 per esclusione, il che significa che il colpo non e' andato a segno
                {
                    P.set_fire(x_action, y_action, 3);  //segnalo sulla griglia del player che non sono state colpite navi, con una O
                }
            }
            else if(ship_size == 3 || ship_size == 1) //caso della nave di supporto e sottomarino
            {
                P.move(x_ship, y_ship, x_action, y_action, ship_size, ship_orientation);    //faccio l'azione move sulla griglia, se il movimento e' possibile...
                P_ships[P_ship_index].move(x_action, y_action);     //...lo faccio anche sulla ship, quindi cambio le coordinate con quelle nuove
                //caso della nave di supporto dopo aver effettuato il move
                if(ship_size==3)
                {   //dato che la nave di supporto e' lunga 3 e ha un area di cura 3x3, per escludere se' stessa dalla cura...
                    if(ship_orientation)    //...se orrizzontale dovro' guardare le navi presenti nell'area 3x3 senza la riga in mezzo, per omettere la nave stessa
                    {
                        int y_temp = y_action -1;
                        while(y_temp <= y_action +1)     //quindi prendo in considerazione le righe 1 e 3 dell'area  
                        {
                            for(int x_temp= x_action-1; x_temp <= x_action+1; x_temp++)   //scorro le righe 1 e 3 per la loro interezza
                            {
                                if(P.get_def_cell(x_temp,y_temp) != DEFAULT_VALUE)    //se la cella non e' vuota
                                {
                                    int restore_index = piece_of_ship(x_temp, y_temp, P_ships);     //mi trovo la nave che corrisponde a quelle coordinate
                                    if(restore_index !=-1 && P_ships[restore_index].is_damaged())   //se trovo una nave che corrisponde ed e' danneggiata
                                    {
                                    P_ships[restore_index].restore_armor();     //ripristino l'armatura
                                    P.set_fixing(P_ships[restore_index].get_x(), P_ships[restore_index].get_y(),
                                        P_ships[restore_index].get_size(), P_ships[restore_index].get_orientation());    //la ripristino anche sulla grid
                                    }
                                }
                            }
                            y_temp += 2;    //per saltare la riga in mezzo
                        }
                    }
                    else    //...se verticale dovro' guardare le navi presenti nell'area 3x3 senza la colonna in mezzo, per omettere la nave stessa
                    {
                        int x_temp = x_action -1;
                        while(x_temp <= x_action +1)     //quindi prendo in considerazione le colonne 1 e 3 dell'area  
                        {
                            for(int y_temp= y_action-1; y_temp <= y_action+1; y_temp++)   //scorro le colonne 1 e 3 per la loro interezza
                            {
                                if(P.get_def_cell(x_temp,y_temp) != DEFAULT_VALUE)    //se la cella non e' vuota
                                {
                                    int restore_index = piece_of_ship(x_temp, y_temp, P_ships);     //mi trovo la nave che corrisponde a quelle coordinate
                                    if(restore_index !=-1 && P_ships[restore_index].is_damaged())   //se trovo una nave che corrisponde ed e' danneggiata
                                    {
                                    P_ships[restore_index].restore_armor();     //ripristino l'armatura
                                    P.set_fixing(P_ships[restore_index].get_x(), P_ships[restore_index].get_y(),
                                        P_ships[restore_index].get_size(), P_ships[restore_index].get_orientation());    //la ripristino anche sulla grid
                                    }
                                }
                            }
                            x_temp += 2;    //per saltare la colonna in mezzo
                        }
                    }
                }
                else    //caso del sottomarino di esplorazione: soltanto visivo, viene modificata solo la grid, non vettore di ship
                {       //scorro la griglia 5x5 con centro il sottomarino
                    for(int x_temp= x_action-2; x_temp <= x_action+2; x_temp++)  
                    {
                        for(int y_temp= y_action-2; y_temp <= y_action+2; y_temp++)
                        {
                            if(C.get_presence(x_temp, y_temp) && !C.out(x_temp, y_temp))  //se la cella avversaria non e' vuota, ed e' dentro la griglia
                            {
                                P.set_presence(x_temp, y_temp, C.get_situation(x_temp, y_temp)); //metto il valore corrispondente sulla griglia del giocatore
                            }                                                                   //seguendo: X colpito, Y non colpito
                        }
                    }
                }
            }
            stop = true;
            //scrivo sul file log le coordinate
            if(write.is_open())
            {
                if(game_mode)   //differenzio i 2 casi per avere una stampa immediata con le stringhe nel caso di partita PC
                {   write<<position1<<" "<<position2<<endl;}
                else
                {   write<<char_converter(x_ship)<<y_ship+1<<" "<<char_converter(x_action)<<y_action+1<<endl;}
            }
            }
            catch(const Ship::Illegal_Ship& e)
            {
                if(game_mode)
                {   cout<<"nessuna nave corrisponde alle coordinate immesse, riprova... ";}
            }
            catch(const Grid::Invalid& e)
            {   
                if(game_mode)
                {   cout<<"coordinate non valide, riprova... ";}
            }
            catch(const invalid_argument& e)
            {
                if(game_mode)
                {   cout<<"e' stato inserito un comando speciale o un formato non valido"<<endl;}
            }
        }   //chiusura del while per le eccezioni
        }   //chiusura dell'if per stabilire il turno
        //TURNO DEL COMPUTER
        else
        {
            while(!stop)    //while fatto in modo tale che venga interrotto il ciclo se non ci sono errori
            {
                try
                {
                bool smart_move = false;
                C_ship_index = corresponding_type(5, C_ships);  //salvo l'indice di una cannoniera, se smart move diventa true, sara' la ship che fa l'azione
                if(C_ship_index != -1)  //se non viene trovata una cannoniera, non svolgo neanche la ricerca delle Y
                {
                    for(int i=0; i<12 && !smart_move; i++)  //fermo il ciclo se viene trovata una smart move
                    {
                        for(int j=0; j<12 && !smart_move; j++)  //fermo il ciclo se viene trovata una smart move
                        {
                            if(C.is_scanned(i, j))  //se viene trovata una Y sulla griglia di attacco
                            {   //salvo le coordinate di questo punto come coordinate dell'azione e imposto smart_move a true
                                x_action = i;
                                y_action = j;
                                smart_move = true;
                                //memorizzo anche le coordinate della ship
                                x_ship = C_ships[C_ship_index].get_x();
                                y_ship = C_ships[C_ship_index].get_y();
                            }
                        }
                    }
                }
                if(!smart_move || C_ship_index==-1) //se non e' stata trovata una smart move, oppure non sono presenti cannoniere...
                {
                    C_ship_index = rand()%(C_ships.size()); //...scelgo casualmente una ship dall'array di ship
                    //memorizzo le coordinate della ship
                    x_ship = C_ships[C_ship_index].get_x();
                    y_ship = C_ships[C_ship_index].get_y();
                    //memorizzo coordinate per l'azione, scelte in modo casuale
                    x_action = rand()%12;
                    y_action = rand()%12;
                }
                //memorizzo in variabili le coordinate e la size della nave
                int ship_size = C_ships[C_ship_index].get_size();
                bool ship_orientation = C_ships[C_ship_index].get_orientation();
                //differenzio l'azione da svolgere in base alla size, che mi dice il tipo di ship indirettamente
                if(ship_size == 5)  //caso della corazzata
                {
                    if(P.get_fire(x_action, y_action) == 1) //caso in cui viene colpita una parte intatta di nave
                    {
                        P_ship_index = piece_of_ship(x_action, y_action, P_ships); //trovo la nave corrispondente del player, nave attaccata
                        if(P_ship_index == -1)          //posso togliere questo controllo in quanto se la nave e' stata trovata sulla griglia allora
                        {   throw Ship::Illegal_Ship();}     //e' presente anche nel vettore, puo' essere tenuto per un controllo ulteriore
                        //aggiorno griglia e armatura
                        C.set_fire(x_action, y_action, 1);      //segnalo nella griglia del player la nave colpita sulla griglia d'attacco con una X
                        P_ships[P_ship_index].decrease_armor(); //diminuisco l'armatura della nave corrispondente
                        P.set_hit(x_action, y_action);          //e aggiorno anche sulla griglia del player segnalando la parte di nave colpita
                        if(P_ships[P_ship_index].is_destroyed())//se distrutta
                        {   //elimino la ship dalla griglia con delete_ship
                            P.delete_ship(P_ships[P_ship_index].get_x(), P_ships[P_ship_index].get_y(),     //brutto 2 righe, ma piu' leggibile(?)
                                P_ships[P_ship_index].get_size(), P_ships[P_ship_index].get_orientation());
                            //elimino la ship dal vettore ships con erase e sfruttando un iteratore
                            remove_ship(P_ship_index, P_ships);
                            if(P_ships.size() == 0)
                            {   
                                win = true; //se il vettore non contiene navi, sono state tutte distrutte, la partita viene vinta
                                cout<<"ha vinto il Computer..."<<endl;
                            }    
                        }
                    }
                    else if(P.get_fire(x_action, y_action) == 2) //caso in cui viene colpita una parte gia' danneggiata di nave
                    {   //non sara' necessario aggiornare l'armatura o la griglia del computer, in quanto la nave era gia' colpita in quel punto
                        C.set_fire(x_action, y_action, 2);   //segnalo nella griglia del player la nave colpita con una x minuscola
                    }
                    else    //get_fire sara' uguale a 3 per esclusione, quindi il colpo non e' andato a segno
                    {
                        C.set_fire(x_action, y_action, 3);  //segnalo sulla griglia del player che non sono state colpite navi, con una O
                    }
                }
                else if(ship_size == 3 || ship_size == 1) //caso della nave di supporto e sottomarino
                {
                    C.move(x_ship, y_ship, x_action, y_action, ship_size, ship_orientation);    //faccio l'azione move sulla griglia, se il movimento e' possibile...
                    C_ships[C_ship_index].move(x_action, y_action);     //...lo faccio anche sulla ship, quindi cambio le coordinate con quelle nuove
                    //caso della nave di supporto dopo aver effettuato il move
                    if(ship_size==3)
                    {   //dato che la nave di supporto e' lunga 3 e ha un area di cura 3x3, per escludere se' stessa dalla cura...
                        if(ship_orientation)    //...se orrizzontale dovro' guardare le navi presenti nell'area 3x3 senza la riga in mezzo, per omettere la nave stessa
                        {
                            int y_temp = y_action -1;
                            while(y_temp <= y_action +1)     //prendo in considerazione le righe 1 e 3 dell'area  
                            {
                                for(int x_temp= x_action-1; x_temp <= x_action+1; x_temp++)   //scorro le righe 1 e 3 per la loro interezza
                                {
                                    if(C.get_def_cell(x_temp,y_temp) != DEFAULT_VALUE)    //se la cella non e' vuota
                                    {
                                        int restore_index = piece_of_ship(x_temp, y_temp, C_ships);     //mi trovo la nave che corrisponde a quelle coordinate
                                        if(restore_index !=-1 && C_ships[restore_index].is_damaged())   //se trovo una nave che corrisponde ed e' danneggiata
                                        {
                                        C_ships[restore_index].restore_armor();     //ripristino l'armatura
                                        C.set_fixing(C_ships[restore_index].get_x(), C_ships[restore_index].get_y(),
                                            C_ships[restore_index].get_size(), C_ships[restore_index].get_orientation());    //la ripristino anche sulla grid
                                        }
                                    }
                                }
                                y_temp += 2;    //per saltare la riga in mezzo
                            }
                        }
                        else    //...se verticale dovro' guardare le navi presenti nell'area 3x3 senza la colonna in mezzo, per omettere la nave stessa
                        {
                            int x_temp = x_action -1;
                            while(x_temp <= x_action +1)     //quindi prendo in considerazione le colonne 1 e 3 dell'area  
                            {
                                for(int y_temp= y_action-1; y_temp <= y_action+1; y_temp++)   //scorro le colonne 1 e 3 per la loro interezza
                                {
                                    if(C.get_def_cell(x_temp,y_temp) != DEFAULT_VALUE)    //se la cella non e' vuota
                                    {
                                        int restore_index = piece_of_ship(x_temp, y_temp, C_ships);     //mi trovo la nave che corrisponde a quelle coordinate
                                        if(restore_index !=-1 && C_ships[restore_index].is_damaged())   //se trovo una nave che corrisponde ed e' danneggiata        
                                        {
                                        C_ships[restore_index].restore_armor();     //ripristino l'armatura
                                        C.set_fixing(C_ships[restore_index].get_x(), C_ships[restore_index].get_y(),
                                            C_ships[restore_index].get_size(), C_ships[restore_index].get_orientation());    //la ripristino anche sulla grid
                                        }
                                    }
                                }
                                x_temp += 2;    //per saltare la colonna in mezzo
                            }
                        }
                    }
                    else    //caso del sottomarino di esplorazione
                    {       //scorro la griglia 5x5 con centro il sottomarino
                        for(int x_temp= x_action-2; x_temp <= x_action+2; x_temp++)  
                        {
                            for(int y_temp= y_action-2; y_temp <= y_action+2; y_temp++)
                            {
                                if(P.get_presence(x_temp, y_temp) && !P.out(x_temp, y_temp))  //se la cella avversaria non e' vuota, ed e' dentro la griglia
                                {
                                    C.set_presence(x_temp, y_temp, P.get_situation(x_temp, y_temp)); //metto il valore corrispondente sulla griglia del giocatore
                                }                                                                   //seguendo: X colpito, Y non colpito
                            }
                        }
                    }
                }
                stop = true;
                //scrivo sul file log le coordinate
                if(write.is_open())
                {   write<<char_converter(x_ship)<<y_ship+1<<" "<<char_converter(x_action)<<y_action+1<<endl;}
                
                }
                catch(const Ship::Illegal_Ship& e)
                {}
                catch(const Grid::Invalid& e)
                {}
                catch(const invalid_argument& e)
                {}
            }

        }//chiusura dell'if, quindi fine del turno

    turn_counter++;
    }
    write.close();

    if(!win)
    {   cout<<"pareggio per raggiungimento limite delle mosse"<<endl;}

       
    return 0;
}


int int_converter(char x_char)
{
    int x_int;
    if(x_char < 65 || x_char > 78 || x_char == 74 || x_char == 75)  //escludo i caratteri prima della A e dopo la N e le lettere J e K
    {   return -1;}                 
    x_int = (int)x_char - 65;       //sfrutto la codifica ASCII: A = 65
    if(x_int > 8) {x_int -= 2;}     //avendo escluso le lettere J e K sottraggo 2 per le lettere dopo di esse
    return x_int;
}

char char_converter(int x_int)
{
    char x_char;
    if(x_int < 0 || x_int > 11)
    {   return -1;}
    if(x_int > 8) {x_int += 2;}     //escludo le lettere J e K
    x_char = (char)x_int + 65;     
    return x_char;
}

string ship_name(int size)
{
    if(size == 5)
    {   return "corazzata (C)";}
    if(size == 3)
    {return "nave di supporto (S)";}
    if(size == 1)
    {return "sottomarino di esplorazione (E)";}
    return "error size";
}

int corresponding_type(int size, vector<Ship> &ships)
{
    for(int i=0; i<ships.size(); i++)   
    {
        if(size == ships[i].get_size()) //comparo con la size
        {   return i;}
    }
    return -1;
}

int corresponding_ship(int x, int y, vector<Ship> &ships)
{
    for(int i=0; i<ships.size(); i++)   //comparo con le coordinate di centro per trovare la ship esatta
    {
        if(x == ships[i].get_x() && y == ships[i].get_y())
        {   return i;}
    }
    return -1;
}

int piece_of_ship(int x, int y, vector<Ship> &ships)
{
    int index = corresponding_ship(x, y, ships);
    if(index != -1)         //se le coordinate corrispondono al centro di una ship del vettore viene ritornato subito il valore corrispondente
    {   return index;}
    //se non corrispondono al centro, controllo se i valori corrispondono a parti di una ship
    for(int i=0; i<ships.size(); i++)
    {
        for(int j=0; j<ships[i].get_size(); j++)
        {
            if(ships[i].get_orientation())  //controllo l'orientamento della ship
            {
                if(y==ships[i].get_y() && x==(ships[i].get_axis_points())[j])   //se e' orrizzontale guardo se la y e' uguale, se lo e' controllo
                {   return i;}                                                  //se una delle x della ship e' uguale alla x data 
            }
            else
            {
                if(x==ships[i].get_x() && y==(ships[i].get_axis_points())[j])   //se e' orrizzontale guardo se la x e' uguale, se lo e' controllo
                {   return i;}                                                  //se una delle y della ship e' uguale alla y data 
            }
        }
    }
    return -1;
}

void remove_ship(int index, vector<Ship> &ships)
{
    vector<Ship>::iterator it = ships.begin();
    it += index;     //it ora punta a index
    ships.erase(it);
}