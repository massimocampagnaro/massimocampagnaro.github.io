//David Cigaia, Massimo Campagnaro e Milos Trifunovic
//Il codice e' stato fatto prendendo delle parti di battaglia_navale
//Massimo ha reso il codice utilizzabile per i replay
//Milos e David hanno aggiunto i vari metodi di scrittura e lettura
#include <iostream>
#include <fstream>
#include <string.h>
#include <vector>
#include <chrono>   //chrono e thread per il rallentamento della stampa delle griglie
#include <thread>
#include "Grid.h"
#include "Ship.h"

using namespace std;

int int_converter(char x_char);    //converte una lettera in un intero: A=0, B=1... escluse J e K
int piece_of_ship(int x, int y, vector<Ship> &ships);    //trova la ship che sta occupando le coordinate immesse e ne restituisce l'indice
void remove_ship(int index, vector<Ship> &ships);
int corresponding_ship(int x, int y, vector<Ship> &ships); //trova la ship con le coordinate di centro corrispondenti a quelle immesse e lo ritorna

int main(int argc, char **argv)
{
    string log_file = "log.txt"; //di default metto log.txt (altrimenti eseguendo replay senza argomenti non farebbe niente);
    bool display_mode = false;  //di default la modalita' di visualizzazione sara' con stampa su cmd
    string print_file;
    //controllo se ci sono argomenti 
    if(argc==3 && strcmp(argv[1], "v") == 0)    //se c'e' l'argomento v
    {   log_file = argv[2];}        //visualizzo le mosse del file dato come argomento successivo
    else if(argc==4 && strcmp(argv[1], "f") == 0)   //se c'e' l'argomento f
    {
        log_file = argv[2];         //prendo le mosse dal file dato come argomento successivo
        print_file = argv[3];       //e le stampo sul file dato come ultimo argomento
        display_mode = true;        //true = stampo la visualizzazione su file
    }
    
    int line_number = 0;
    int first_player;   //player = 1, computer = 0
    char delimiter = ' ';
    
    fstream read;
    read.open(log_file, ios::in);// apro la lettura del file log
    fstream write;
    if(display_mode)
    write.open(print_file,ios::out); //sovrascrivo il testo ogni volta che chiudo e riapro il file
    string line;

    //posizionamento delle ship del computer 1
    Grid C;     //griglia del computer 1
    vector<Ship> C_ships;   //vettore del computer 1

    int size = 5;

    if(display_mode)
    {   write<<"posizionamento del giocatore 1: "<<endl;}
    else
    cout<<"posizionamento del giocatore 1: "<<endl;
    for(int i=0;i<8;i++)// righe del posizionamento delle ship del computer
    {
        getline(read,line);
        line_number++;
        //divido la line in 2 parti con un delimiter ' '
        string position1 =line.substr(0, line.find(delimiter));     //salvo la prima parte
        line.erase(0, line.find(delimiter) + 1);    //elimino la prima parte
        string position2 =line;     //salvo la seconda parte

        int y1 = stoi(position1.substr(1));
        y1--;   //sottraggo di uno per ottenere numeri da 0 a 11 (per valori array)
        int y2 = stoi(position2.substr(1)); 
        y2--;   //sottraggo di uno per ottenere numeri da 0 a 11 (per valori array)
        int x1 = int_converter(position1[0]);  //converto il primo valore da carattere a intero
        int x2 = int_converter(position2[0]);

        C_ships.push_back(Ship(x1, y1, x2, y2, size));    //creo una ship del vettore con le coordinate date
        C.set_ship(C_ships[i].get_x(), C_ships[i].get_y(), size, C_ships[i].get_orientation());  //setto la ship prendendomi le coordinate con i get

        if(display_mode)
        {   write<<C.to_string();}
        else
        {
            C.visualize_grid();
            this_thread::sleep_for(chrono::milliseconds(1000)); //pausa di 1 secondo
        }

        if(i == 2 || i == 5)    //se ha messo 3 ship di size 5 passo a quelle di size 3 e cosi via (si ferma a 8 quindi solo 2 sottomarini)
        size -= 2;
    }

    //posizionamento navi del player, o computer 2
    Grid P;     //griglia del player
    vector<Ship> P_ships;  //vettore del player

    size = 5;
    if(display_mode)
    {   write<<"posizionamento del giocatore 2: "<<endl;}
    else
    cout<<"posizionamento del giocatore 2: "<<endl;
    for(int i=0;i<8;i++)
    {
        getline(read,line);
        line_number++;
        //divido la line in 2 parti con un delimiter ' '
        string position1 =line.substr(0, line.find(delimiter));     //salvo la prima parte
        line.erase(0, line.find(delimiter) + 1);    //elimino la prima parte
        string position2 =line;     //salvo la seconda parte

        int y1 = stoi(position1.substr(1));
        y1--;   //sottraggo di uno per ottenere numeri da 0 a 11 (per valori array)
        int y2 = stoi(position2.substr(1)); 
        y2--;   //sottraggo di uno per ottenere numeri da 0 a 11 (per valori array)
        int x1 = int_converter(position1[0]);  //converto il primo valore da carattere a intero
        int x2 = int_converter(position2[0]);

        P_ships.push_back(Ship(x1, y1, x2, y2, size));    //aggiungo al vettore una ship con le coordinate date
        P.set_ship(P_ships[i].get_x(), P_ships[i].get_y(), size, P_ships[i].get_orientation());  //setto la ship prendendomi le caratteristiche con i get

        if(display_mode)
        {   write<<P.to_string();}
        else
        {
            P.visualize_grid();
            this_thread::sleep_for(chrono::milliseconds(1000)); //pausa di 1 secondo
        }

        if(i == 2 || i == 5)    //se ha messo 3 ship di size 5 passo a quelle di size 3 e cosi via (si ferma a 8 quindi solo 2 sottomarini)
        size -= 2;
    }
    

    if(line_number == 16)   // mi prende solamente la 16-esima riga del file log (dove metto chi inizia la partita)
    {
        getline(read,line);
        line_number++;
        first_player = stoi(line);  //player = 1, computer = 0
    }

    bool win = false;
    while(getline(read,line) && !win)
    {

        //divido la line in 2 parti con un delimiter ' '
        string position1 =line.substr(0, line.find(delimiter));     //salvo la prima parte
        line.erase(0, line.find(delimiter) + 1);    //elimino la prima parte
        string position2 =line;     //salvo la seconda parte
        
        int y_ship = stoi(position1.substr(1));
        y_ship--;   //sottraggo di uno per ottenere numeri da 0 a 11 (per valori array)
        int y_action = stoi(position2.substr(1)); 
        y_action--;   //sottraggo di uno per ottenere numeri da 0 a 11 (per valori array)
        int x_ship = int_converter(position1[0]);  //converto il primo valore da carattere a intero
        int x_action = int_converter(position2[0]);

        // x1 e y1 corrisponderanno al centro di una nave, mentre x2, y2 corrisponderanno alla x e y dell'azione 
        // manca la gestione delle mosse senza il bisogno di contare gli errori in quanto è una parita già stata fatta

        int P_ship_index, C_ship_index; 

        if(first_player==0)// turno giocatore 1 (computer 1)
        {
            C_ship_index = corresponding_ship(x_ship, y_ship, C_ships); //trovo la nave corrispondente del player, per l'azione
                
            //memorizzo in variabili le coordinate e la size della nave
            int ship_size = C_ships[C_ship_index].get_size();
            bool ship_orientation = C_ships[C_ship_index].get_orientation();

            if(ship_size == 5)  //caso della corazzata
            {
                if(P.get_fire(x_action, y_action) == 1) //caso in cui viene colpita una parte intatta di nave
                {
                    P_ship_index = piece_of_ship(x_action, y_action, P_ships); //trovo la nave corrispondente del player, nave attaccata
                        
                    //aggiorno griglia e armatura
                    C.set_fire(x_action, y_action, 1);      //segnalo nella griglia del player la nave colpita sulla griglia d'attacco con una X
                    P_ships[P_ship_index].decrease_armor(); //diminuisco l'armatura della nave corrispondente
                    P.set_hit(x_action, y_action);          //e aggiorno anche sulla griglia del computer segnalando la nave colpita
                    if(P_ships[P_ship_index].is_destroyed())//se distrutta
                    {   //elimino la ship dalla griglia con delete_ship
                        P.delete_ship(P_ships[P_ship_index].get_x(), P_ships[P_ship_index].get_y(),     //brutto 2 righe, ma piu' leggibile(?)
                        P_ships[P_ship_index].get_size(), P_ships[P_ship_index].get_orientation());
                        //elimino la ship dal vettore ships con erase e sfruttando un iteratore
                        remove_ship(P_ship_index, P_ships);
                        if(P_ships.size() == 0)
                        {   
                            win = true; //se il vettore non contiene navi, sono state tutte distrutte, la partita viene vinta dal player
                            if(display_mode)
                            {   
                                write<<"griglia giocatore1:"<<endl<<C.to_string();
                                write<<"griglia giocatore2:"<<endl<<P.to_string();
                                write<<"Il giocatore1 ha vinto la partita!!\n";
                            }
                            else
                            {   
                                cout<<"griglia giocatore1:"<<endl<<C.to_string();
                                cout<<"griglia giocatore2:"<<endl<<P.to_string();
                                cout<<"Il giocatore1 ha vinto la partita!!\n";
                            }
                        }
                    }
                }
                else if(P.get_fire(x_action, y_action) == 2) //caso in cui viene colpita una parte gia' danneggiata di nave
                {   //non sara' necessario aggiornare l'armatura o la griglia del computer, in quanto la nave era gia' colpita in quel punto
                    C.set_fire(x_action, y_action, 2);   //segnalo nella griglia del player la nave colpita con una x minuscola
                }
                else    //get_fire sara' uguale a 3 per esclusione, quindi il colpo non e' andato a segno
                {
                    C.set_fire(x_action, y_action, 3);  //segnalo sulla griglia del player che non sono state colpite navi, con una O
                }
            }
            else if(ship_size == 3 || ship_size == 1) //caso della nave di supporto e sottomarino
            {
                C.move(x_ship, y_ship, x_action, y_action, ship_size, ship_orientation);    //faccio l'azione move sulla griglia, se il movimento e' possibile...
                C_ships[C_ship_index].move(x_action, y_action);     //...lo faccio anche sulla ship, quindi cambio le coordinate con quelle nuove
                //caso della nave di supporto dopo aver effettuato il move
                if(ship_size==3)
                {   //dato che la nave di supporto e' lunga 3 e ha un area di cura 3x3, per escludere se' stessa dalla cura...
                    if(ship_orientation)    //...se orrizzontale dovro' guardare le navi presenti nell'area 3x3 senza la riga in mezzo, per omettere la nave stessa
                    {
                        int y_temp = y_action -1;
                        while(y_temp <= y_action +1)     //prendo in considerazione le righe 1 e 3 dell'area  
                        {
                            for(int x_temp= x_action-1; x_temp <= x_action+1; x_temp++)   //scorro le righe 1 e 3 per la loro interezza
                            {
                                if(C.get_def_cell(x_temp,y_temp) != DEFAULT_VALUE)    //se la cella non e' vuota
                                {
                                    int restore_index = piece_of_ship(x_temp, y_temp, C_ships);     //mi trovo la nave che corrisponde a quelle coordinate
                                    if(restore_index !=-1 && C_ships[restore_index].is_damaged())   //se trovo una nave che corrisponde ed e' danneggiata
                                    {
                                        C_ships[restore_index].restore_armor();     //ripristino l'armatura
                                        C.set_fixing(C_ships[restore_index].get_x(), C_ships[restore_index].get_y(),
                                        C_ships[restore_index].get_size(), C_ships[restore_index].get_orientation());    //la ripristino anche sulla grid
                                    }
                                }
                            }
                                y_temp += 2;    //per saltare la riga in mezzo
                        }
                    }
                    else    //...se verticale dovro' guardare le navi presenti nell'area 3x3 senza la colonna in mezzo, per omettere la nave stessa
                    {
                        int x_temp = x_action -1;
                        while(x_temp <= x_action +1)     //quindi prendo in considerazione le colonne 1 e 3 dell'area  
                        {
                            for(int y_temp= y_action-1; y_temp <= y_action+1; y_temp++)   //scorro le colonne 1 e 3 per la loro interezza
                            {
                                if(C.get_def_cell(x_temp,y_temp) != DEFAULT_VALUE)    //se la cella non e' vuota
                                {
                                    int restore_index = piece_of_ship(x_temp, y_temp, C_ships);     //mi trovo la nave che corrisponde a quelle coordinate
                                    if(restore_index !=-1 && C_ships[restore_index].is_damaged())   //se trovo una nave che corrisponde ed e' danneggiata        
                                    {
                                        C_ships[restore_index].restore_armor();     //ripristino l'armatura
                                        C.set_fixing(C_ships[restore_index].get_x(), C_ships[restore_index].get_y(),
                                        C_ships[restore_index].get_size(), C_ships[restore_index].get_orientation());    //la ripristino anche sulla grid
                                    }
                                }
                            }
                            x_temp += 2;    //per saltare la colonna in mezzo
                        }
                    }
                }
                else    //caso del sottomarino di esplorazione
                {       //scorro la griglia 5x5 con centro il sottomarino
                    for(int x_temp= x_action-2; x_temp <= x_action+2; x_temp++)  
                    {
                        for(int y_temp= y_action-2; y_temp <= y_action+2; y_temp++)
                        {
                            if(P.get_presence(x_temp, y_temp) && !P.out(x_temp, y_temp))  //se la cella avversaria non e' vuota, ed e' dentro la griglia
                            {
                                C.set_presence(x_temp, y_temp, P.get_situation(x_temp, y_temp)); //metto il valore corrispondente sulla griglia del giocatore
                            }                                                                   //seguendo: X colpito, Y non colpito
                        }
                    }
                }
            }
            if(!win)
            {
                if(display_mode)
                {
                    write<<"griglia giocatore1: "<<endl;
                    write<<C.to_string();
                }
                else
                {
                    cout<<"griglia giocatore1: "<<endl;
                    C.visualize_grid();
                    this_thread::sleep_for(chrono::milliseconds(1000)); //pausa di 1 secondo
                }
            }

            first_player++ ;

        }else   // turno giocatore 2 (player o computer 2)
        {
            P_ship_index = corresponding_ship(x_ship, y_ship, P_ships); //trovo la nave corrispondente del player, per l'azione
                
            //memorizzo in variabili la size e l'orientation della nave
            int ship_size = P_ships[P_ship_index].get_size();
            bool ship_orientation = P_ships[P_ship_index].get_orientation();

            if(ship_size==5)
            {
                if(C.get_fire(x_action, y_action) == 1) //caso in cui viene colpita una parte intatta di nave
                {
                    C_ship_index = piece_of_ship(x_action, y_action, C_ships); //trovo la nave corrispondente del computer, nave attaccata
                        
                    //aggiorno griglia e armatura
                    P.set_fire(x_action, y_action, 1);      //segnalo nella griglia del player la nave colpita sulla griglia d'attacco con una X
                    C_ships[C_ship_index].decrease_armor(); //diminuisco l'armatura della nave corrispondente
                    C.set_hit(x_action, y_action);          //e aggiorno anche sulla griglia del computer segnalando la nave colpita
                    if(C_ships[C_ship_index].is_destroyed())//se distrutta
                    {   //elimino la ship dalla griglia con delete_ship
                        C.delete_ship(C_ships[C_ship_index].get_x(), C_ships[C_ship_index].get_y(),
                        C_ships[C_ship_index].get_size(), C_ships[C_ship_index].get_orientation());
                        //elimino la ship dal vettore ships
                        remove_ship(C_ship_index, C_ships);
                        if(C_ships.size() == 0)
                        {   
                            win = true; //se il vettore non contiene navi, sono state tutte distrutte, la partita viene vinta dal player
                            if(display_mode)
                            {
                                write<<"griglia giocatore2:"<<endl<<P.to_string();
                                write<<"griglia giocatore1:"<<endl<<C.to_string();   
                                write<<"Il giocatore2 ha vinto la partita!!\n";
                            }
                            else
                            {   
                                cout<<"griglia giocatore2:"<<endl<<P.to_string();
                                cout<<"griglia giocatore1:"<<endl<<C.to_string();
                                cout<<"Il giocatore2 ha vinto la partita!!\n";
                            }
                        }   
                    }
                }
                else if(C.get_fire(x_action, y_action) == 2) //caso in cui viene colpita una parte gia' danneggiata di nave
                {   //non sara' necessario aggiornare l'armatura o la griglia del computer, in quanto la nave era gia' colpita in quel punto
                    P.set_fire(x_action, y_action, 2);   //segnalo nella griglia del player la nave colpita con una x minuscola
                }
                else    //get_fire sara' uguale a 3 per esclusione, il che significa che il colpo non e' andato a segno
                {
                    P.set_fire(x_action, y_action, 3);  //segnalo sulla griglia del player che non sono state colpite navi, con una O
                }


            }else if(ship_size==3 || ship_size==1)
            {
                P.move(x_ship, y_ship, x_action, y_action, ship_size, ship_orientation);    //faccio l'azione move sulla griglia, se il movimento e' possibile...
                P_ships[P_ship_index].move(x_action, y_action);     //...lo faccio anche sulla ship, quindi cambio le coordinate con quelle nuove
                //caso della nave di supporto dopo aver effettuato il move
                if(ship_size==3)
                {   //dato che la nave di supporto e' lunga 3 e ha un area di cura 3x3, per escludere se' stessa dalla cura...
                    if(ship_orientation)    //...se orrizzontale dovro' guardare le navi presenti nell'area 3x3 senza la riga in mezzo, per omettere la nave stessa
                    {
                        int y_temp = y_action -1;
                        while(y_temp <= y_action +1)     //quindi prendo in considerazione le righe 1 e 3 dell'area  
                        {
                            for(int x_temp= x_action-1; x_temp <= x_action+1; x_temp++)   //scorro le righe 1 e 3 per la loro interezza
                            {
                                if(P.get_def_cell(x_temp,y_temp) != DEFAULT_VALUE)    //se la cella non e' vuota
                                {
                                    int restore_index = piece_of_ship(x_temp, y_temp, P_ships);     //mi trovo la nave che corrisponde a quelle coordinate
                                    if(restore_index !=-1 && P_ships[restore_index].is_damaged())   //se trovo una nave che corrisponde ed e' danneggiata
                                    {
                                        P_ships[restore_index].restore_armor();     //ripristino l'armatura
                                        P.set_fixing(P_ships[restore_index].get_x(), P_ships[restore_index].get_y(),
                                        P_ships[restore_index].get_size(), P_ships[restore_index].get_orientation());    //la ripristino anche sulla grid
                                    }
                                }
                            }
                            y_temp += 2;    //per saltare la riga in mezzo
                        }
                    }
                    else    //...se verticale dovro' guardare le navi presenti nell'area 3x3 senza la colonna in mezzo, per omettere la nave stessa
                    {
                        int x_temp = x_action -1;
                        while(x_temp <= x_action +1)     //quindi prendo in considerazione le colonne 1 e 3 dell'area  
                        {
                            for(int y_temp= y_action-1; y_temp <= y_action+1; y_temp++)   //scorro le colonne 1 e 3 per la loro interezza
                            {
                                if(P.get_def_cell(x_temp,y_temp) != DEFAULT_VALUE)    //se la cella non e' vuota
                                {
                                    int restore_index = piece_of_ship(x_temp, y_temp, P_ships);     //mi trovo la nave che corrisponde a quelle coordinate
                                    if(restore_index !=-1 && P_ships[restore_index].is_damaged())   //se trovo una nave che corrisponde ed e' danneggiata
                                    {
                                        P_ships[restore_index].restore_armor();     //ripristino l'armatura
                                        P.set_fixing(P_ships[restore_index].get_x(), P_ships[restore_index].get_y(),
                                        P_ships[restore_index].get_size(), P_ships[restore_index].get_orientation());    //la ripristino anche sulla grid
                                    }
                                }
                            }
                            x_temp += 2;    //per saltare la colonna in mezzo
                        }
                    }
                }
                else    //caso del sottomarino di esplorazione: soltanto visivo, viene modificata solo la grid, non vettore di ship
                {       //scorro la griglia 5x5 con centro il sottomarino
                    for(int x_temp= x_action-2; x_temp <= x_action+2; x_temp++)  
                    {
                        for(int y_temp= y_action-2; y_temp <= y_action+2; y_temp++)
                        {
                            if(C.get_presence(x_temp, y_temp) && !C.out(x_temp, y_temp))  //se la cella avversaria non e' vuota, ed e' dentro la griglia
                            {
                                P.set_presence(x_temp, y_temp, C.get_situation(x_temp, y_temp)); //metto il valore corrispondente sulla griglia del giocatore
                            }                                                                   //seguendo: X colpito, Y non colpito
                        }
                    }
                }
            }
            if(!win)
            {    
                if(display_mode)
                {
                    write<<"griglia giocatore2:"<<endl;
                    write<<P.to_string();
                }
                else
                {
                    cout<<"griglia giocatore2:"<<endl;
                    P.visualize_grid();
                    this_thread::sleep_for(chrono::milliseconds(1000)); //pausa di 1 secondo
                }
            }

            first_player-- ;
        }
        line_number++;
    
    }
    if(!win)
    {   
        if(display_mode)
        {   write<<"la partita e' terminata con un pareggio...";}
        else
        {   cout<<"la partita e' terminata con un pareggio...";}
    }

    if(display_mode)
    {   write.close();}     //se era stato aperto, chiudo la scrittura sul file print

    read.close();// chiudo la lettura del file log

    return 0;
}

int int_converter(char x_char)
{
    int x_int;
    if(x_char < 65 || x_char > 78 || x_char == 74 || x_char == 75)  //escludo i caratteri prima della A e dopo la N e le lettere J e K
    {   return -1;}                 
    x_int = (int)x_char - 65;       //sfrutto la codifica ASCII: A = 65
    if(x_int > 8) {x_int -= 2;}     //avendo escluso le lettere J e K sottraggo 2 per le lettere dopo di esse
    return x_int;
}

int corresponding_ship(int x, int y, vector<Ship> &ships)
{
    for(int i=0; i<ships.size(); i++)   //comparo con le coordinate di centro per trovare la ship esatta
    {
        if(x == ships[i].get_x() && y == ships[i].get_y())
        {   return i;}
    }
    return -1;
}

int piece_of_ship(int x, int y, vector<Ship> &ships)
{
    int index = corresponding_ship(x, y, ships);
    if(index != -1)         //se le coordinate corrispondono al centro di una ship del vettore viene ritornato subito il valore corrispondente
    {   return index;}
    //se non corrispondono al centro, controllo se i valori corrispondono a parti di una ship
    for(int i=0; i<ships.size(); i++)
    {
        for(int j=0; j<ships[i].get_size(); j++)
        {
            if(ships[i].get_orientation())  //controllo l'orientamento della ship
            {
                if(y==ships[i].get_y() && x==(ships[i].get_axis_points())[j])   //se e' orrizzontale guardo se la y e' uguale, se lo e' controllo
                {   return i;}                                                  //se una delle x della ship e' uguale alla x data 
            }
            else
            {
                if(x==ships[i].get_x() && y==(ships[i].get_axis_points())[j])   //se e' orrizzontale guardo se la x e' uguale, se lo e' controllo
                {   return i;}                                                  //se una delle y della ship e' uguale alla y data 
            }
        }
    }
    return -1;
}

void remove_ship(int index, vector<Ship> &ships)
{
    vector<Ship>::iterator it = ships.begin();
    it += index;     //it ora punta a index
    ships.erase(it);
}
